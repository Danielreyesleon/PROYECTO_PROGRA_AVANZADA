

import argparse
from scapy.all import ARP, Ether


def mostrar_datos(ip_victima, ip_gateway, mac_falsa, vm_ip=None, vm_user=None):
    if vm_ip or vm_user:
        print("Acceso a la VM (AWS):")
        if vm_ip:
            print(f"  IP Pública: {vm_ip}")
        if vm_user:
            print(f"  Usuario : {vm_user}")
        print()

    print("Datos de la simulación:")
    print(f"  IP víctima: {ip_victima}")
    print(f"  IP gateway: {ip_gateway}")
    print(f"  MAC falsa : {mac_falsa}")
    print()


def spoof_simulado(ip_victima, ip_gateway, mac_falsa, vm_ip=None, vm_user=None):
    mostrar_datos(ip_victima, ip_gateway, mac_falsa, vm_ip, vm_user)
    print("Simulación de ARP Spoofing")


    pkt = Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(
        op=2,
        psrc=ip_gateway,
        pdst=ip_victima,
        hwsrc=mac_falsa,
        hwdst="00:00:00:00:00:00"
    )

    print("\nPaquete generado (no enviado):")
    print(pkt.summary())
    print()
    pkt.show()

    # guardamos una representación legible del paquete para el informe
    with open("paquete_simulado.txt", "w", encoding="utf-8") as f:
        if vm_ip or vm_user:
            f.write("Acceso a la VM (AWS):\n")
            if vm_ip:
                f.write(f"IP Pública: {vm_ip}\n")
            if vm_user:
                f.write(f"Usuario : {vm_user}\n")
            f.write("\n")

        f.write("Simulación de ARP Spoofing\n")
        f.write(f"IP víctima: {ip_victima}\n")
        f.write(f"IP gateway: {ip_gateway}\n")
        f.write(f"MAC falsa : {mac_falsa}\n")
        f.write("\n")
        f.write(pkt.summary() + "\n\n")
        f.write(pkt.show(dump=True))

    print("\nPaquete guardado en paquete_simulado.txt\n")


def crear_parser():
    parser = argparse.ArgumentParser(
        description="Genera una simulación de ARP spoofing sin enviar paquetes reales."
    )
    parser.add_argument(
        "ip_victima",
        nargs="?",
        default="100.55.25.242",
        help="IP de la víctima (por defecto 100.55.25.242)",
    )
    parser.add_argument(
        "ip_gateway",
        nargs="?",
        default="100.55.25.1",
        help="IP del gateway simulado (por defecto 100.55.25.1)",
    )
    parser.add_argument(
        "mac_falsa",
        nargs="?",
        default="aa:bb:cc:dd:ee:ff",
        help="MAC falsa que se usará como origen (por defecto aa:bb:cc:dd:ee:ff)",
    )
    parser.add_argument("--vm-ip", help="IP pública de la VM AWS (opcional)")
    parser.add_argument("--vm-user", help="Usuario de la VM AWS (opcional)")
    return parser


def main():
    parser = crear_parser()
    args = parser.parse_args()

    spoof_simulado(
        args.ip_victima,
        args.ip_gateway,
        args.mac_falsa,
        vm_ip=args.vm_ip,
        vm_user=args.vm_user,
    )


if __name__ == "__main__":
    main()
