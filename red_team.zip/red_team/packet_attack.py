import sys
from scapy.all import ARP, Ether

# Validar argumentos
if len(sys.argv) != 4:
    print("Uso: python packet_attack.py <IP_victima> <IP_gateway> <MAC_falsa>")
    sys.exit()

def spoof_simulado(ip_victima, ip_gateway, mac_falsa):
    print("\nSimulación de ARP Spoofing\n")

    pkt = Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(
        op=2,
        psrc=ip_gateway,
        pdst=ip_victima,
        hwsrc=mac_falsa
    )

    print("Paquete generado (no enviado):")
    print(pkt.summary())
    pkt.show()

    with open("paquete_simulado.txt", "w") as f:
        f.write(str(pkt))

    print("\nPaquete guardado en paquete_simulado.txt\n")

spoof_simulado(sys.argv[1], sys.argv[2], sys.argv[3])
