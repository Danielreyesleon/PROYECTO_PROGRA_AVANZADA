import nmap
import sys

def escanear(ip):
    nm = nmap.PortScanner()
    nm.scan(ip, arguments="-sV -Pn")
    
    if ip not in nm.all_hosts():
        print("no se logro escnear el IP")
        return
    
    print(f"\n El Resultado de el ip es  {ip}: ")
    for p, info in nm[ip]["tcp"].items():
        print(f"{p}/tcp {info['state']}  {info['name']} {info.get('version', '')}")
        
        
if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit()
    
    escanear(sys.argv[1])