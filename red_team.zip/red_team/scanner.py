

import sys
import nmap


IP_OBJETIVO = "100.55.25.242"
PUERTOS = "22,80,443" 


def obtener_host(nm, ip):
    """nmap a veces devuelve la ip con otro formato, buscamos el host correcto"""
    hosts = nm.all_hosts()
    if not hosts:
        return None

    if ip in hosts:
        return ip


    if len(hosts) == 1:
        return hosts[0]


    for host in hosts:
        if nm[host].get("addresses", {}).get("ipv4") == ip:
            return host

    return hosts[0]


def escanear(ip):
    print(f"[*] Escaneando {ip}...")
    print(f"[*] Puertos a revisar: {PUERTOS}")

    try:
        nm = nmap.PortScanner()
        
        argumentos = f"-sV -Pn -sT --reason -p {PUERTOS} --host-timeout 120s"
        nm.scan(ip, arguments=argumentos)
    except nmap.PortScannerError as e:
        print(f"[!] Error con nmap: {e}")
        print("[!] Verifica que nmap este instalado")
        return
    except Exception as e:
        print(f"[!] Error: {e}")
        return

    host_ip = obtener_host(nm, ip)
    if host_ip is None:
        print("no se logro escanear el IP")
        return

    if host_ip != ip:
        print(f"[*] Host detectado como: {host_ip}")

    host = nm[host_ip]
    stats = nm.scanstats()

    print(f"\n========== Resultado del escaneo: {ip} ==========\n")

    # datos generales del escaneo
    print(f" Tiempo transcurrido: {stats.get('elapsed', '?')} segundos")
    print(f" Hosts activos: {stats.get('uphosts', '?')} / {stats.get('totalhosts', '?')}")


    estado = host.get("status", {}).get("state", "desconocido")
    razon_host = host.get("status", {}).get("reason", "")
    print(f"\n--- Informacion del host ---")
    print(f" Estado: {estado}" + (f" ({razon_host})" if razon_host else ""))

    direcciones = host.get("addresses", {})
    if direcciones:
        print(f" Direcciones:")
        for tipo, valor in direcciones.items():
            print(f"   {tipo}: {valor}")


    vendor = host.get("vendor", {})
    if vendor:
        for mac, nombre in vendor.items():
            print(f" Fabricante ({mac}): {nombre}")

    # nombres del host
    hostnames = host.get("hostnames", [])
    nombres = [h["name"] for h in hostnames if h.get("name")]
    if nombres:
        print(f" Hostname(s): {', '.join(nombres)}")

    if "tcp" not in host:
        print("\n no se encontraron puertos tcp")
        return

    abiertos = 0
    filtrados = 0
    cerrados = 0

    print(f"\n--- Puertos TCP encontrados ---\n")

    for puerto in sorted(host["tcp"].keys(), key=int):
        info = host["tcp"][puerto]
        state = info.get("state", "?")

        if state == "open":
            abiertos += 1
        elif state == "filtered":
            filtrados += 1
        elif state == "closed":
            cerrados += 1

        servicio = info.get("name", "desconocido")
        producto = info.get("product", "")
        version = info.get("version", "")
        extra = info.get("extrainfo", "")
        razon = info.get("reason", "")
        confianza = info.get("conf", "")


        if producto:
            detalle_servicio = producto
            if version:
                detalle_servicio += " " + version
        else:
            detalle_servicio = version

        print(f" Puerto {puerto}/tcp")
        print(f"   Estado: {state}")
        print(f"   Servicio: {servicio}")
        if detalle_servicio:
            print(f"   Version detectada: {detalle_servicio}")
        if extra:
            print(f"   Info extra: {extra}")
        if razon:
            print(f"   Razon: {razon}")
        if confianza != "":
            print(f"   Confianza: {confianza}%")

        cpe = info.get("cpe", "")
        if cpe:
            print(f"   CPE: {cpe}")

        print("")

    print("--- Resumen ---")
    print(f" Puertos abiertos: {abiertos}")
    print(f" Puertos filtrados: {filtrados}")
    print(f" Puertos cerrados: {cerrados}")
    print(f" Total analizados: {len(host['tcp'])}\n")


if __name__ == "__main__":
    if len(sys.argv) == 2:
        ip = sys.argv[1]
    elif len(sys.argv) == 1:
        ip = IP_OBJETIVO
        print(f"[*] Usando IP del laboratorio: {ip}")
    else:
        print("Uso: python scanner.py [IP]")
        print(f"      Si no pones IP, usa la del proyecto: {IP_OBJETIVO}")
        sys.exit(1)

    escanear(ip)
